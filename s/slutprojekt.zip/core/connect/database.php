<?php
    $config = array(
		'host'     => '10.246.16.217:3306',
		'username' => 'asjstrand_com',
		'password' => 'taklampa96',
		'dbname'   => 'asjstrand_com'
	);

	$db = new PDO('mysql:host=' . $config['host'] . ';dbname=' . $config['dbname'], $config['username'], $config['password']);

	$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
?>